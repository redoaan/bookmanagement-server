## Express JS Node JS Complete Authentication API
### Video Link:- https://youtu.be/2pn2Bspt6EM

## To Run this Project via NPM follow below:

```bash
npm install
npm run dev
```

#### There is a Folder "PostmanEndpoints" which has Postman Collection File You can import this file in your postman to test this API

